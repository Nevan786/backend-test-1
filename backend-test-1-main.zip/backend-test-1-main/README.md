# Alba Corp Backend Test

This test is a 2-DAY test with 3 Parts.<br />
Part 1: NodeJS + ExpressJS APIs Test<br />
Part 2: JestJS tests Test<br />
Part 3: CLEAN architecture with MongoDB Test

The test is made to be sequential, you should do it by order.

Fork this repo, and when you are done send us the link for your forked version.

The 2 days will be calculated based on when we sent you the email for test to when you last committed the code in your repo.
