export default {

  SUPPORTED_DATABASE: {
    MONGO: 'mongo',
  }

};
